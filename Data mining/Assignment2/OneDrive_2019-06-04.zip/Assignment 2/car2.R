# install.packages("rpart")
# install.packages("pROC")
# install.packages('caTools')
# install.packages("randomForest")
# install.packages("caret")
# install.packages("e1071")

setwd("D:/r-workspace/Assignments/Assignment2")

library(rpart)
library(pROC)
library(randomForest)
library(caret)

carData=read.csv("car.csv")
summary(carData)
# View(carData)

x=carData[,1:6]
y=carData[,7]
#View(x)
#View(y)

# Splitting the dataset into the Training set and Test set
library(caTools)
set.seed(123)
split = sample.split(carData$shouldBuy, SplitRatio = 0.75)
training_set = subset(carData, split == TRUE)
test_set = subset(carData, split == FALSE)

list_data <- c()

library(rpart)
for (i in seq(100, 200, 10)){
  treeCar = rpart(shouldBuy~.,data=training_set,method="class",control=rpart.control(minsplit=i))
  #Pridiction
  predCar=predict(treeCar,test_set,type="class")
  #Matrix
  treeCM=table(test_set[,7],predCar)
  treeCM
  #Accuracy
  accuracy = sum(diag(treeCM))/sum(treeCM)
  list_data <- c(list_data,accuracy)
}

temp_list_data <- c(seq(100, 200, 10)) 
temp_list_data
list_data
plot(list_data,x=temp_list_data)
plot(y=list_data,x=temp_list_data,
     main = "Decision Tree - Accuracy of Test Dataset for Different Min Splits (100-200)",
     ylab = "Accuracy",
     xlab = "Min Split Value")


# Try rpart
library(rpart)
treeCar = rpart(shouldBuy~.,data=training_set,method="class",control=rpart.control(minsplit=140))
treeCar
# Plot Decision Tree
# plot(treeCar)
# text(treeCar)
# title(main = "Decision Tree")
#Pridiction
predCar=predict(treeCar,test_set,type="class")
#Matrix
treeCM=table(test_set[,7],predCar)
treeCM
#Accuracy of the prediction using Decision Tree
accuracy=sum(diag(treeCM))/sum(treeCM)

#Kfold with rpar - Decision Tree
library(caret)
library(e1071)
control <- trainControl(method="cv", number=10, savePredictions=TRUE)
seed <- 123
metric <- "Accuracy"
set.seed(seed)
rf_default <- train(x,y, method="rpart", metric=metric, control = rpart.control(minsplit = 140), 
                    trControl=control)
print(rf_default)
varImp(rf_default)
ggplot(varImp(rf_default))


#--------------------------------------------------------------------------------------------------------


# #Try randomForest

# library(pROC)
# predCarProb=predict(treeCar,newdata=carData,type="prob")
# roc(carData[,7],predCarProb[,2]) # what is this 2 ? *****
# plot(roc(carData[,7],predCarProb[,2]))
# 
# 
setwd("D:/r-workspace/Assignments/Assignment2")

library(rpart)
library(pROC)
library(randomForest)
library(caret)

carData=read.csv("car.csv")
summary(carData)
# View(carData)

# Splitting the dataset into the Training set and Test set
library(caTools)
set.seed(123)
split = sample.split(carData$shouldBuy, SplitRatio = 0.75)
training_set = subset(carData, split == TRUE)
test_set = subset(carData, split == FALSE)

x=training_set[,1:6]
y=training_set[,7]

list_data <- c()

library(randomForest)
for (i in seq(100, 700, 10)){
  rf=randomForest(x,y, ntree=i)
  rfp=predict(rf,test_set)
  rfCM=table(rfp,test_set[,7])
  # rfCM
  #Accuracy of the prediction using randomForest
  accuracy = sum(diag(rfCM))/sum(rfCM)
  list_data <- c(list_data,accuracy)
}

temp_list_data <- c(seq(100, 700, 10)) 
temp_list_data
list_data
plot(list_data,x=temp_list_data)


#--------------------------------------------------------------------------------------------------------

x=training_set[,1:6]
y=training_set[,7]


rf=randomForest(x,y, ntree=500)

rfProb=predict(rf,x,type="prob")
roc.multi = multiclass.roc(carData[,7],rfProb)
rs <- roc.multi[['rocs']]
plot.roc(rs[[1]], rfProb)
sapply(2:length(rs),function(i) lines.roc(rs[[1]],col=1))


rf=randomForest(x,y, ntree=500)
rfp=predict(rf,test_set)
rfCM=table(rfp,test_set[,7])
# rfCM
#Accuracy of the prediction using randomForest
accuracy = sum(diag(rfCM))/sum(rfCM)
accuracy



library(caret)
library(e1071)
control <- trainControl(method="cv", number=10, savePredictions=TRUE)
seed <- 123
metric <- "Accuracy"
set.seed(seed)
rf_default <- train(x,y, method="rpart", metric=metric, control = rpart.control(minsplit = 140), 
                    trControl=control)
print(rf_default)
varImp(rf_default)
ggplot(varImp(rf_default))


rs[1]
lines.roc(rs[1],rfProb,col=1)

# If you have more than two classes, you can run this separately for each class
multiclass.roc(carData[,7],rfProb)
plot(multiclass.roc(carData[,7],rfProb))


roc(carData[,7],rfProb[,1])
plot(roc(carData[,7],rfProb[,1]))
title(main = "RandomForest Probability using 500 node")
roc(carData[,7],rfProb[,2])
plot(roc(carData[,7],rfProb[,2]))
title(main = "RandomForest Probability using 500 node (Class 2)")
roc(carData[,7],rfProb[,3])
plot(roc(carData[,7],rfProb[,3]))
title(main = "RandomForest Probability using 500 node (Class 3)")
roc(carData[,7],rfProb[,4])
plot(roc(carData[,7],rfProb[,4]))
title(main = "RandomForest Probability using 500 node (Class 4)")


#--------------------------------------------------------------------------------------------------------


x=carData[,1:6]
y=carData[,7]

# Use caret package for 10 fold cross validation
library(caret)
control <- trainControl(method="repeatedcv", number=10, repeats=3)
seed <- 123
metric <- "Accuracy"
set.seed(seed)
rf_default <- train(x,y, method="rf", metric=metric, trControl=control)
print(rf_default)
varImp(rf_default)
ggplot(varImp(rf_default))


# 
# rf=randomForest(x,y,nodesize=50) # what is nodesize ? *****
# rfp=predict(rf,x)
# rfCM=table(rfp,y)
# rfCM
# #Accuracy of the prediction using randomForest and node 50
# sum(diag(rfCM))/sum(rfCM)
# rfProb=predict(rf,x,type="prob")
# 
# # sensitivity is the ability to correctly identify a given class
# # specificity is the ability to correctly identify those who are in different class(es)
# # Here, we are using the second column that means class 'M'
# 
# # If we have more than two classes you need to use multiclass.roc
# # roc(carData[,7],rfProb[,2])
# 
# # plot(roc(carData[,7],rfProb[,2]))
# # title(main = "RandomForest Probability using 50 node (Class 2)")
# 
# # If you have more than two classes, you can run this separately for each class
# roc(carData[,7],rfProb[,1])
# plot(roc(carData[,7],rfProb[,1]))
# title(main = "RandomForest Probability using 50 node (Class 1)")
# roc(carData[,7],rfProb[,2])
# plot(roc(carData[,7],rfProb[,2]))
# title(main = "RandomForest Probability using 50 node (Class 2)")
# roc(carData[,7],rfProb[,3])
# plot(roc(carData[,7],rfProb[,3]))
# title(main = "RandomForest Probability using 50 node (Class 3)")
# roc(carData[,7],rfProb[,4])
# plot(roc(carData[,7],rfProb[,4]))
# title(main = "RandomForest Probability using 50 node (Class 4)")
# 
# rf=randomForest(x,y,nodesize=10)
# rfp=predict(rf,x)
# rfCM=table(rfp,y)
# rfCM
# #Accuracy of the prediction using randomForest and node 10
# sum(diag(rfCM))/sum(rfCM)
# rfProb=predict(rf,x,type="prob")
# #roc(carData[,7],rfProb[,2])
# #plot(roc(carData[,7],rfProb[,2]))
# 
# # If you have more than two classes, you can run this separately for each class
# roc(carData[,7],rfProb[,1])
# plot(roc(carData[,7],rfProb[,1]))
# title(main = "RandomForest Probability using 10 node (Class 1)")
# roc(carData[,7],rfProb[,2])
# plot(roc(carData[,7],rfProb[,2]))
# title(main = "RandomForest Probability using 10 node (Class 2)")
# roc(carData[,7],rfProb[,3])
# plot(roc(carData[,7],rfProb[,3]))
# title(main = "RandomForest Probability using 10 node (Class 3)")
# roc(carData[,7],rfProb[,4])
# plot(roc(carData[,7],rfProb[,4]))
# title(main = "RandomForest Probability using 10 node (Class 4)")
# 
# # Use caret package for 10 fold cross validation
# library(caret)
# control <- trainControl(method="repeatedcv", number=10, repeats=3)
# seed <- 7
# metric <- "Accuracy"
# set.seed(seed)
# rf_default <- train(x,y, method="rf", metric=metric, trControl=control)
# library(caret)
# control <- trainControl(method="repeatedcv", number=10, repeats=3)
# rf_default <- train(x,y, method="rf", metric=metric, trControl=control)
# print(rf_default)
# varImp(rf_default)
# ggplot(varImp(rf_default))

# library(caret)
# library(e1071)
# control <- trainControl(method="cv", number=10, savePredictions=TRUE)
# seed <- 7
# metric <- "Accuracy"
# set.seed(seed)
# rf_default <- train(x,y, method="rpart", metric=metric, control = rpart.control(minsplit = 500), 
#                     trControl=control)
# print(rf_default)
# varImp(rf_default)
# ggplot(varImp(rf_default))

#-------------------------------------------

#Extra

