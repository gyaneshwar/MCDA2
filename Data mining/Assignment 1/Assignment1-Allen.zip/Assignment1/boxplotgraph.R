boxplot(prod$BASKETS)
title("Box Plots of BASKETS")

boxplot(prod$TOTAL_REVENUE)
title("Box Plots of TOTAL_REVENUE")

boxplot(prod$DISTINCT_CUSTOMERS)
title("Box Plots of DISTINCT_CUSTOMERS")

boxplot(prod$AVERAGE_PRICE)
title("Box Plots of AVERAGE_PRICE")